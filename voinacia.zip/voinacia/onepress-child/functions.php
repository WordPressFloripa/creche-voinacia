<?php


/* ============================================================================
  REGISTRA SCRIPTS
  ========================================================================== */


function wpfloripa_enqueue_styles() {

    $parent_style = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
    wp_enqueue_style('font-fredoka', 'https://fonts.googleapis.com/css?family=Fredoka+One', array(), null, 'screen');
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}
add_action( 'wp_enqueue_scripts', 'wpfloripa_enqueue_styles' );


// Style the login area
  function my_login_logo() { ?>
  	<style type="text/css">
  	.login a:active, 
  	.login a:hover,
  	body.login #nav a:hover,
  	body.login #backtoblog a:hover {
  		color: #2e5dae
  	}
  	#login h1 a, 
  	.login h1 a {
  		background-image: url(/wp-content/uploads/2018/09/creche-vo-inacia-logo.jpg);
  		height: 93px;
  		width: 200px;
  		background-size: 200px 93px;
  		background-repeat: no-repeat;
  	}
  	body.login {
  		background: #ffffff;
  	}
  	body.login #login_error, 
  	body.login .message {
  		border-left: 4px solid #004f8c;
  	}
  	body.login form {
  		box-shadow: 0 1px 5px rgba(0,0,0,.33);
  	}
  </style>
<?php }

// return to home on login logo click
add_action( 'login_enqueue_scripts', 'my_login_logo' );
function my_login_logo_url() {
	return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );
// login image title
function my_login_logo_url_title() {
	return 'Creche Vó Inácia';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );
